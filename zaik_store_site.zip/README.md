# Zaik' Store Demo

This is a single-file website ready to upload on **GitHub Pages**.

## 🚀 How to Publish on GitHub Pages

1. Go to [https://github.com](https://github.com) and create a new public repository (example: `zaik-store`).
2. Upload the file `index.html` in that repository.
3. Commit (save) the upload.
4. Go to **Settings → Pages** (or `https://github.com/<your-username>/<repo-name>/settings/pages`).
5. Under **Source**, choose branch `main` and folder `/ (root)`.
6. Save.  
   Your site will be live at:  
   `https://<your-username>.github.io/<repo-name>/`

Enjoy your free hosted website!
